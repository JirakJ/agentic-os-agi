'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const { performance } = require('node:perf_hooks');
const fixed = require('../src/sprintf.js');
let checked = 0;
const examples = [
  ['%s', ['hello'], 'hello'], ['%d', [42], '42'], ['%+05d', [42], '+0042'],
  ['%-6s', ['cat'], 'cat   '], ['%.3s', ['abcdef'], 'abc'],
  ['%.2f', [3.14159], '3.14'], ['%2$s %1$s', ['one', 'two'], 'two one'],
  ['%(person.name)s', [{person:{name:'Ada'}}], 'Ada'],
  ['%X', [255], 'FF'], ['%b', [5], '101'], ['%t', [1], 'true'],
  ['%T', [[]], 'array'], ['%j', [{a:1}], '{"a":1}'], ['100%% %s', ['ok'], '100% ok']
];
for (const [format, args, expected] of examples) {
  assert.equal(fixed.sprintf(format, ...args), expected); checked++;
}
assert.equal(fixed.vsprintf('%s:%d', ['port', 80]), 'port:80'); checked++;
for (const format of ['%65537s', '%2147483647s', '%.65537s', '%.999999999999999999999f', '%(x)999999999s', '%1$999999999s']) {
  let evaluated = false;
  const started = performance.now();
  assert.throws(() => fixed.sprintf(format, () => { evaluated = true; return 'x'; }), RangeError);
  assert.equal(evaluated, false);
  assert.ok(performance.now() - started < 1000, 'hostile format must fail promptly'); checked++;
}
assert.equal(fixed.sprintf('%65536s', 'x').length, 65536); checked++;
assert.equal(fixed.sprintf('%.65536s', 'abc'), 'abc'); checked++;
const browser = { window: {} };
vm.runInNewContext(fs.readFileSync(require.resolve('../dist/sprintf.min.js'), 'utf8'), browser);
assert.equal(browser.window.sprintf('%04d', 7), '0007'); checked++;
assert.throws(() => browser.window.sprintf('%999999999s', 'x'), /exceeds 65536/); checked++;
console.log(JSON.stringify({ status: 'pass', assertions: checked, patch: 'GHSA-hp3w-g68c-fv3c', version: '1.1.4-security.1' }));
